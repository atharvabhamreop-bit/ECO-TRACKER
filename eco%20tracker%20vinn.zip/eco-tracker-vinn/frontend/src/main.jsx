import React,{useState}from"react";
import{createRoot}from"react-dom/client";
import{BrowserRouter,useNavigate,useLocation,Routes,Route,Link,Navigate}from"react-router-dom";
import"./style.css";

const A=[["Walking / Cycling",15,"🚲"],["Public Transport",10,"🚌"],["Recycling",10,"♻️"],["Avoid Single-use Plastic",5,"🥤"],["Saving Electricity",10,"⚡"],["Planting a Tree",25,"🌳"]];
const B=[["Green Starter",50,"🌱"],["Eco Explorer",100,"🧭"],["Eco Champion",250,"🏆"],["Planet Protector",500,"🌍"]];
const data=()=>JSON.parse(localStorage.getItem("eco")||'{"points":0,"logs":[]}');
const save=x=>localStorage.setItem("eco",JSON.stringify(x));

function Side(){
 let n=useNavigate(),l=useLocation();
 return <aside>
  <div className="brand"><span>🌱</span><div><b>ECO-TRACKER</b><small>Live greener</small></div></div>
  {["dashboard","activities","progress","leaderboard","profile","content","help","contact"].map(x=>
   <button key={x} className={l.pathname.includes(x)?"on":""} onClick={()=>n("/"+x)}>
    {({dashboard:"🏠",activities:"🌿",progress:"📈",leaderboard:"🏆",profile:"👤",content:"📚",help:"❓",contact:"✉️"})[x]} {x[0].toUpperCase()+x.slice(1)}
   </button>)}
  <button className="logout" onClick={()=>{localStorage.removeItem("user");n("/")}}>↪ Logout</button>
 </aside>
}
function Layout({children}){
 let d=data();
 return <div className="layout"><Side/><main>
  <header><div><b>Eco Tracker</b><span>Welcome back 🌍</span></div><div className="topscore">🌱 {d.points} pts</div></header>{children}
 </main></div>
}
function Home(){
 const [count,setCount]=useState(0);
 return <div className="home">
  <nav><Link to="/" className="logo">🌱 ECO-TRACKER</Link><div><a href="#features">Features</a><a href="#about">About</a><Link to="/contact">Contact</Link><Link to="/login">Login</Link><Link className="btn" to="/signup">Get Started</Link></div></nav>
  <section className="hero"><div className="heroText"><span className="pill">🌍 MAKE EVERY ACTION COUNT</span><h1>Track your habits.<br/><em>Protect the planet.</em></h1><p>Complete sustainable activities, earn Eco Points, unlock badges and build a greener lifestyle—one small action at a time.</p><div className="actions"><Link className="btn big" to="/signup">Start Your Journey →</Link><Link className="ghost" to="/content">Learn More</Link></div><div className="trust"><span>♻️ 6 activities</span><span>🏆 4 badges</span><span>📊 Live progress</span></div></div>
  <div className="heroVisual"><div className="orb">🌱<strong>{count}</strong><small>Eco Points</small></div><div className="float f1">♻️ Recycle +10</div><div className="float f2">🌳 Plant a tree +25</div><button className="miniAction" onClick={()=>setCount(count+10)}>＋ Try earning points</button></div></section>
  <section id="features" className="features"><div><span>🌿</span><h3>Track Activities</h3><p>Record everyday eco-friendly actions in seconds.</p></div><div><span>🏆</span><h3>Earn Rewards</h3><p>Collect points and unlock meaningful badges.</p></div><div><span>📈</span><h3>See Your Progress</h3><p>Watch your environmental journey grow over time.</p></div></section>
  <section id="about" className="about"><span className="pill">ABOUT ECO-TRACKER</span><h2>Small actions can create a <em>big impact.</em></h2><p>Eco-Tracker helps students and communities turn sustainable choices into visible progress. Walk, recycle, save electricity, use public transport and more.</p></section>
  <footer>© 2026 Eco-Tracker · Contact: ecoact@gmail.com · 9082871533</footer>
 </div>
}
function Auth({signup=false}){
 let n=useNavigate(),[f,setF]=useState({});
 return <div className="auth"><form onSubmit={e=>{e.preventDefault();localStorage.setItem("user",JSON.stringify(f));if(signup)save({points:0,logs:[]});n("/dashboard")}}>
  <Link to="/" className="back">← Home</Link><div className="authLogo">🌱</div><h2>{signup?"Create your account":"Welcome back!"}</h2><p>{signup?"Start your greener journey today.":"Continue your eco journey."}</p>
  {signup&&<input required placeholder="Full name" onChange={e=>setF({...f,name:e.target.value})}/>}
  <input required type="email" placeholder="Email" onChange={e=>setF({...f,email:e.target.value})}/><input required type="password" placeholder="Password" onChange={e=>setF({...f,password:e.target.value})}/><button className="btn">{signup?"Sign Up":"Login"}</button>
  <Link to={signup?"/login":"/signup"}>{signup?"Already have an account? Login":"New here? Create an account"}</Link>
 </form></div>
}
function Dashboard(){
 let d=data(),u=JSON.parse(localStorage.getItem("user")||"{}");
 return <Layout><div className="pageTitle"><div><span className="eyebrow">YOUR ECO JOURNEY</span><h1>Hello, {u.name||"Eco Friend"} 👋</h1><p>Keep making small changes for a healthier planet.</p></div><Link className="btn" to="/activities">＋ Add Activity</Link></div>
 <div className="stats">{[["🌱","Eco Points",d.points],["🌿","Activities",d.logs.length],["🏆","Badges",B.filter(b=>d.points>=b[1]).length],["🔥","Streak",Math.min(d.logs.length,7)+" days"]].map(x=><div className="stat" key={x[1]}><span>{x[0]}</span><small>{x[1]}</small><b>{x[2]}</b></div>)}</div>
 <div className="twoCol"><div className="panel"><div className="panelHead"><h2>Recent activities</h2><Link to="/activities">View all</Link></div>{d.logs.length?<div>{d.logs.slice(-5).reverse().map((x,i)=><div className="activityRow" key={i}><span>🌿</span><div><b>{x.name}</b><small>{x.date}</small></div><strong>+{x.points}</strong></div>)}</div>:<div className="empty">No activities yet. Start your journey today! 🌱</div>}</div>
 <div className="panel impact"><span className="bigLeaf">🌍</span><h2>Your impact</h2><p>Every sustainable choice adds up.</p><div className="impactLine"><b>{d.points}</b><span>points earned</span></div><Link className="btn" to="/progress">View Progress</Link></div></div></Layout>
}
function Activities(){
 let[d,setD]=useState(data());
 const add=a=>{let x={...d,points:d.points+a[1],logs:[...d.logs,{name:a[0],points:a[1],date:new Date().toLocaleDateString()}]};setD(x);save(x)};
 return <Layout><div className="pageTitle"><div><span className="eyebrow">GO GREEN</span><h1>Eco Activities</h1><p>Choose an action and earn points.</p></div></div><div className="grid">{A.map(a=><div className="card" key={a[0]}><span className="emoji">{a[2]}</span><h3>{a[0]}</h3><b>+{a[1]} points</b><button onClick={()=>add(a)}>Complete Activity ✓</button></div>)}</div></Layout>
}
function Progress(){let d=data();return <Layout><span className="eyebrow">YOUR ACHIEVEMENTS</span><h1>Progress</h1><div className="panel progressBox"><div><h2>{d.points} Eco Points</h2><p>Next badge: {B.find(b=>d.points<b[1])?.[0]||"Planet Protector"}</p></div><strong>{Math.min((d.points/500)*100,100).toFixed(0)}%</strong><div className="bar"><i style={{width:Math.min(d.points/5,100)+"%"}}/></div></div><div className="grid">{B.map(b=><div className={"card badge "+(d.points>=b[1]?"unlock":"")} key={b[0]}><span className="emoji">{b[2]}</span><h3>{b[0]}</h3><p>{b[1]} points</p><b>{d.points>=b[1]?"✓ Unlocked":"🔒 Locked"}</b></div>)}</div></Layout>}
function Leaderboard(){return <Layout><span className="eyebrow">COMMUNITY</span><h1>Leaderboard</h1><div className="panel leaderboard">{[["🥇","Green Hero",850],["🥈","Planet Saver",720],["🥉","Eco Warrior",610],["🌱","You",data().points]].map((x,i)=><div className={i===3?"you":""} key={x[1]}><span>{x[0]}</span><b>{x[1]}</b><strong>{x[2]} pts</strong></div>)}</div></Layout>}
function Profile(){let u=JSON.parse(localStorage.getItem("user")||"{}");return <Layout><span className="eyebrow">ACCOUNT</span><h1>Profile</h1><div className="panel profile"><div className="avatar">👤</div><h2>{u.name||"Eco User"}</h2><p>{u.email||"No email"}</p><span className="tag">🌱 Eco Member</span></div></Layout>}
function Content(){return <Layout><span className="eyebrow">LEARN & ACT</span><h1>Eco Content</h1><div className="contentGrid">{[["♻️","Why Recycling Matters","Recycling reduces waste, saves resources and helps keep useful materials in circulation."],["⚡","Save Electricity","Switch off unused lights and devices, use efficient appliances and make natural light your first choice."],["🚌","Choose Greener Travel","Walking, cycling and public transport can reduce unnecessary fuel use and support cleaner cities."],["🌳","Protect Green Spaces","Plant and care for trees, avoid littering and encourage others to protect local biodiversity."]].map(x=><div className="contentCard" key={x[1]}><span>{x[0]}</span><h3>{x[1]}</h3><p>{x[2]}</p></div>)}</div></Layout>}
function Help(){return <Layout><span className="eyebrow">SUPPORT</span><h1>Help Center</h1><div className="faq">{[["How do I earn points?","Open Eco Activities, choose an activity and press Complete Activity."],["Where can I see my badges?","Open Progress to see unlocked and locked badges."],["Can I see my recent activities?","Yes. Your latest activities appear on the Dashboard."],["Need more help?","Contact our team using the details on the Contact page."]].map(x=><details key={x[0]}><summary>{x[0]}</summary><p>{x[1]}</p></details>)}</div></Layout>}
function Contact(){return <Layout><span className="eyebrow">WE ARE HERE TO HELP</span><h1>Contact Us</h1><div className="contactGrid"><div className="panel contactCard"><span className="contactIcon">✉️</span><h2>Eco-Tracker Support</h2><p>Have a question, suggestion or feedback? Get in touch with us.</p><a href="mailto:ecoact@gmail.com">📧 ecoact@gmail.com</a><a href="tel:9082871533">📞 9082871533</a></div><form className="panel contactForm" onSubmit={e=>{e.preventDefault();alert("Thank you! Your message is ready to be sent to ecoact@gmail.com.")}}><input required placeholder="Your name"/><input required type="email" placeholder="Your email"/><textarea required placeholder="Write your message..."></textarea><button className="btn">Send Message →</button></form></div></Layout>}
function App(){return <Routes><Route path="/" element={<Home/>}/><Route path="/login" element={<Auth/>}/><Route path="/signup" element={<Auth signup/>}/><Route path="/dashboard" element={<Dashboard/>}/><Route path="/activities" element={<Activities/>}/><Route path="/progress" element={<Progress/>}/><Route path="/leaderboard" element={<Leaderboard/>}/><Route path="/profile" element={<Profile/>}/><Route path="/content" element={<Content/>}/><Route path="/help" element={<Help/>}/><Route path="/contact" element={<Contact/>}/><Route path="*" element={<Navigate to="/"/>}/></Routes>}
createRoot(document.getElementById("root")).render(<BrowserRouter><App/></BrowserRouter>);

# ECO-TRACKER VINN

An improved Eco-Tracker web application for tracking sustainable activities.

## Added in this version
- Dynamic landing page with animated-style interactive point demo
- Content section with eco-learning cards
- Help Center with expandable FAQs
- Contact page
- Contact email: ecoact@gmail.com
- Contact phone: 9082871533
- Improved responsive UI and dashboard
- Activity history, points, badges and progress using localStorage
- Leaderboard and profile pages

## Run Frontend
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal.

## Run Backend
The Spring Boot backend remains included in `backend/`.
Configure MySQL password in:
`backend/src/main/resources/application.properties`

Database:
```sql
CREATE DATABASE eco_tracker;
```

Backend:
```bash
cd backend
mvn spring-boot:run
```
